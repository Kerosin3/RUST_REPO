#![feature(associated_type_defaults)]
#![feature(is_some_and)]
#[allow(unused_imports)]
#[allow(unused_variables)]
#[allow(dead_code)]
pub mod home;

pub fn add(left: usize, right: usize) -> usize {
    left + right
}
