pub mod server_data;
pub mod termometer_server_data;
