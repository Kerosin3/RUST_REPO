# smart house example

* common behavior using static dispatching (traits)

## Usage

* use `cargo run --example %example_file_name%` to run an example
* use `cargo test` to run unit tests
* use `cargo test --test '*'` to run all integration test
* use `cargo test --test %integration test filename %` to run one integration test
* pass `-- --nocapture` to a test to enable println output

