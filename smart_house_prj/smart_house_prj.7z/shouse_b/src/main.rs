fn main() {
    lib_shouse::add(5, 5);
    lib_shouse::home::home::smart_house::run_me();
}
