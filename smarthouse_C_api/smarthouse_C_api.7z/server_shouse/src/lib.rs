pub mod server;
pub mod udp_termo_data_server;
pub mod update_termometer_client;
